package com.example.weatherapp


import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.squareup.moshi.Moshi
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

// Weather data models
data class WeatherResponse(val main: Main, val weather: List<Weather>, val name: String)
data class Main(val temp: Double)
data class Weather(val description: String)

// Retrofit API Interface
interface WeatherApiService {
    @GET("weather")
    suspend fun getCurrentWeather(
        @Query("lat") latitude: Double,
        @Query("lon") longitude: Double,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric" // Metric for Celsius, "imperial" for Fahrenheit
    ): WeatherResponse
}

// ViewModel class to handle business logic
class WeatherViewModel : ViewModel() {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/data/2.5/")
        .addConverterFactory(MoshiConverterFactory.create(Moshi.Builder().build()))
        .build()

    private val weatherApiService = retrofit.create(WeatherApiService::class.java)

    suspend fun getWeather(lat: Double, lon: Double, apiKey: String): WeatherResponse {
        return weatherApiService.getCurrentWeather(lat, lon, apiKey)
    }
}

// MainActivity handling the UI and business logic
class MainActivity : AppCompatActivity() {

    private lateinit var weatherViewModel: WeatherViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)

        // Initialize ViewModel
        weatherViewModel = ViewModelProvider(this).get(WeatherViewModel::class.java)

        // Latitude and Longitude for New York City (example)
        val latitude = 40.7128
        val longitude = -74.0060
        val apiKey = "your-api-key-here" // Insert your OpenWeatherMap API key here

        // Fetch weather data
        fetchWeatherData(latitude, longitude, apiKey)
    }

    private fun fetchWeatherData(lat: Double, lon: Double, apiKey: String) {
        lifecycleScope.launch {
            try {
                val weatherResponse = weatherViewModel.getWeather(lat, lon, apiKey)

                // Convert Celsius to Fahrenheit
                val tempCelsius = weatherResponse.main.temp
                val tempFahrenheit = (tempCelsius * 9/5) + 32

                // Update the UI
                findViewById<TextView>(R.id.weatherTempCTextView).text = "Temp: $tempCelsius°C"
                findViewById<TextView>(R.id.weatherTempFTextView).text = "Temp: $tempFahrenheit°F"
                findViewById<TextView>(R.id.weatherDescTextView).text = "Description: ${weatherResponse.weather[0].description}"
                findViewById<TextView>(R.id.locationTextView).text = "Location: ${weatherResponse.name}"
            } catch (e: Exception) {
                e.printStackTrace()
                findViewById<TextView>(R.id.errorTextView).text = "Error fetching weather data"
            }
        }
    }
}
